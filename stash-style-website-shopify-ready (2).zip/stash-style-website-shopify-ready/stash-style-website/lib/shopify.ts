export const SHOPIFY_DOMAIN = process.env.NEXT_PUBLIC_SHOPIFY_STORE_DOMAIN as string;
export const STOREFRONT_TOKEN = process.env.NEXT_PUBLIC_SHOPIFY_STOREFRONT_TOKEN as string;

if (!SHOPIFY_DOMAIN || !STOREFRONT_TOKEN) {
  console.warn("⚠️ Missing Shopify env vars: NEXT_PUBLIC_SHOPIFY_STORE_DOMAIN or NEXT_PUBLIC_SHOPIFY_STOREFRONT_TOKEN");
}

export async function shopifyFetch<T = any>(query: string, variables: Record<string, any> = {}): Promise<T> {
  const res = await fetch(`https://${SHOPIFY_DOMAIN}/api/2025-01/graphql.json`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Storefront-Access-Token": STOREFRONT_TOKEN || "",
    },
    body: JSON.stringify({ query, variables }),
    // Next.js caching hint (safe on server)
    // @ts-ignore
    next: { revalidate: 60 },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Shopify API error ${res.status}: ${text}`);
  }
  return res.json() as Promise<T>;
}

export const QUERIES = {
  PRODUCTS: `
    query Products($first: Int = 12) {
      products(first: $first) {
        edges {
          node {
            id
            title
            description
            handle
            images(first: 1) { edges { node { url altText } } }
            variants(first: 1) { edges { node { id price { amount currencyCode } } } }
          }
        }
      }
    }`,
  CHECKOUT_CREATE: `
    mutation checkoutCreate($lineItems: [CheckoutLineItemInput!]!) {
      checkoutCreate(input: { lineItems: $lineItems }) {
        checkout { webUrl }
        userErrors { field message }
      }
    }`,
};
