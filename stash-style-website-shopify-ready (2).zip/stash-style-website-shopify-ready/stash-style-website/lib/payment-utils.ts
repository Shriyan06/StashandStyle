export interface PaymentDetails {
  amount: number
  currency?: string
  paymentMethod: "card" | "paypal" | "cashapp"
  billingDetails: {
    name: string
    email: string
    address: {
      line1: string
      city: string
      state: string
      postal_code: string
      country: string
    }
  }
  cardDetails?: {
    number: string
    exp_month: number
    exp_year: number
    cvc: string
  }
}

export async function createPaymentIntent(amount: number, paymentMethod: string) {
  const response = await fetch("/api/create-payment-intent", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount,
      currency: "usd",
      paymentMethod,
    }),
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.error || "Failed to create payment intent")
  }

  return response.json()
}

export async function confirmPayment(paymentIntentId: string, paymentDetails: PaymentDetails) {
  const response = await fetch("/api/confirm-payment", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      paymentIntentId,
      paymentMethod: paymentDetails.paymentMethod,
      billingDetails: paymentDetails.billingDetails,
      cardDetails: paymentDetails.cardDetails,
    }),
  })

  const result = await response.json()

  if (!response.ok) {
    throw new Error(result.message || result.error || "Payment failed")
  }

  return result
}

export function validateCardNumber(cardNumber: string): boolean {
  // Remove spaces and non-digits
  const cleaned = cardNumber.replace(/\D/g, "")

  // Check length (13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false
  }

  // Luhn algorithm for basic validation
  let sum = 0
  let isEven = false

  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = Number.parseInt(cleaned[i])

    if (isEven) {
      digit *= 2
      if (digit > 9) {
        digit -= 9
      }
    }

    sum += digit
    isEven = !isEven
  }

  return sum % 10 === 0
}

export function validateExpiryDate(expiry: string): boolean {
  const match = expiry.match(/^(\d{2})\/(\d{2})$/)
  if (!match) return false

  const month = Number.parseInt(match[1])
  const year = Number.parseInt(match[2]) + 2000

  if (month < 1 || month > 12) return false

  const now = new Date()
  const currentYear = now.getFullYear()
  const currentMonth = now.getMonth() + 1

  if (year < currentYear || (year === currentYear && month < currentMonth)) {
    return false
  }

  return true
}

export function formatCardNumber(value: string): string {
  const cleaned = value.replace(/\D/g, "")
  const match = cleaned.match(/(\d{0,4})(\d{0,4})(\d{0,4})(\d{0,4})/)
  if (!match) return cleaned

  return [match[1], match[2], match[3], match[4]]
    .filter((group) => group.length > 0)
    .join(" ")
    .trim()
}

export function formatExpiryDate(value: string): string {
  const cleaned = value.replace(/\D/g, "")
  if (cleaned.length >= 2) {
    return cleaned.substring(0, 2) + (cleaned.length > 2 ? "/" + cleaned.substring(2, 4) : "")
  }
  return cleaned
}
