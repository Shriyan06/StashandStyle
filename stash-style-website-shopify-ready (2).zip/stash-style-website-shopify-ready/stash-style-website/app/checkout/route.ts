import { NextRequest, NextResponse } from "next/server";
import { shopifyFetch, QUERIES } from "@/lib/shopify";

export async function GET(req: NextRequest) {
  const variantId = req.nextUrl.searchParams.get("variantId");
  const qty = parseInt(req.nextUrl.searchParams.get("qty") || "1");

  if (!variantId) return NextResponse.redirect(new URL("/", req.url));

  const data = await shopifyFetch<any>(QUERIES.CHECKOUT_CREATE, {
    lineItems: [{ variantId, quantity: qty }],
  });

  const checkoutUrl = data?.data?.checkoutCreate?.checkout?.webUrl || "/";
  return NextResponse.redirect(checkoutUrl);
}
