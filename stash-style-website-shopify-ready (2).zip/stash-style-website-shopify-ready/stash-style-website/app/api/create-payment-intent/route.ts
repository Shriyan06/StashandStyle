import { type NextRequest, NextResponse } from "next/server"

// Mock Stripe integration - in production, you would use the actual Stripe SDK
export async function POST(request: NextRequest) {
  try {
    const { amount, currency = "usd", paymentMethod } = await request.json()

    // Validate amount
    if (!amount || amount < 50) {
      // Minimum $0.50
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 })
    }

    // Mock payment intent creation
    const paymentIntent = {
      id: `pi_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      client_secret: `pi_${Date.now()}_secret_${Math.random().toString(36).substr(2, 9)}`,
      amount: Math.round(amount * 100), // Convert to cents
      currency,
      status: "requires_payment_method",
      payment_method: paymentMethod,
    }

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    })
  } catch (error) {
    console.error("Payment intent creation failed:", error)
    return NextResponse.json({ error: "Failed to create payment intent" }, { status: 500 })
  }
}
