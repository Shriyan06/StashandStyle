import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { paymentIntentId, paymentMethod, billingDetails } = await request.json()

    // Mock payment confirmation
    // In production, this would integrate with actual payment processors

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock different payment methods
    let success = true
    let paymentMethodType = "card"

    switch (paymentMethod) {
      case "card":
        // Mock card payment processing
        paymentMethodType = "card"
        // Simulate occasional failures for testing
        success = Math.random() > 0.1 // 90% success rate
        break
      case "paypal":
        paymentMethodType = "paypal"
        success = Math.random() > 0.05 // 95% success rate
        break
      case "cashapp":
        paymentMethodType = "cashapp"
        success = Math.random() > 0.05 // 95% success rate
        break
      default:
        return NextResponse.json({ error: "Unsupported payment method" }, { status: 400 })
    }

    if (!success) {
      return NextResponse.json(
        {
          error: "Payment failed",
          message: "Your payment could not be processed. Please try again or use a different payment method.",
        },
        { status: 400 },
      )
    }

    // Mock successful payment response
    const confirmedPayment = {
      id: paymentIntentId,
      status: "succeeded",
      payment_method: {
        type: paymentMethodType,
        billing_details: billingDetails,
      },
      amount_received: Math.round(Math.random() * 50000 + 5000), // Mock amount in cents
      created: Math.floor(Date.now() / 1000),
      receipt_url: `https://pay.stripe.com/receipts/${paymentIntentId}`,
    }

    return NextResponse.json({
      success: true,
      payment: confirmedPayment,
      orderId: `SS${Date.now().toString().slice(-6)}`,
    })
  } catch (error) {
    console.error("Payment confirmation failed:", error)
    return NextResponse.json({ error: "Payment confirmation failed" }, { status: 500 })
  }
}
