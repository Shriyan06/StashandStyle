import { NextRequest, NextResponse } from "next/server";
import { shopifyFetch, QUERIES } from "@/lib/shopify";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { variantId, quantity = 1 } = body || {};

  if (!variantId) {
    return NextResponse.json({ error: "Missing variantId" }, { status: 400 });
  }

  const data = await shopifyFetch<any>(QUERIES.CHECKOUT_CREATE, {
    lineItems: [{ variantId, quantity }],
  });

  const url = data?.data?.checkoutCreate?.checkout?.webUrl;
  const errors = data?.data?.checkoutCreate?.userErrors;

  if (url) {
    return NextResponse.json({ url }, { status: 200 });
  }
  return NextResponse.json({ error: "Checkout creation failed", details: errors }, { status: 500 });
}
