import { NextRequest, NextResponse } from "next/server";
import { shopifyFetch, QUERIES } from "@/lib/shopify";

export async function GET(req: NextRequest) {
  const firstParam = req.nextUrl.searchParams.get("first");
  const first = firstParam ? parseInt(firstParam) : 12;

  const data = await shopifyFetch<any>(QUERIES.PRODUCTS, { first });

  return NextResponse.json({
    products: data.data.products.edges.map((e: any) => ({
      id: e.node.id,
      title: e.node.title,
      description: e.node.description,
      handle: e.node.handle,
      image: e.node.images.edges?.[0]?.node?.url || null,
      variantId: e.node.variants.edges?.[0]?.node?.id || null,
      price: e.node.variants.edges?.[0]?.node?.price?.amount || null,
      currencyCode: e.node.variants.edges?.[0]?.node?.price?.currencyCode || null,
    })),
  }, { status: 200 });
}
