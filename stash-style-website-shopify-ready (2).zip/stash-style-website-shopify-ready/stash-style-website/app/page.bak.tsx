import { shopifyFetch } from "@/lib/shopify";

const query = `
{
  products(first: 8) {
    edges {
      node {
        id
        title
        description
        images(first: 1) {
          edges { node { url altText } }
        }
        variants(first: 1) {
          edges {
            node {
              id
              price { amount currencyCode }
            }
          }
        }
      }
    }
  }
}`;

export default async function HomePage() {
  const response = await shopifyFetch(query);
  const products = response.data.products.edges;

  return (
    <main className="p-10 grid grid-cols-1 md:grid-cols-3 gap-6">
      {products.map(({ node }: any) => (
        <div key={node.id} className="border rounded-xl p-4 shadow">
          <img
            src={node.images.edges[0]?.node.url}
            alt={node.images.edges[0]?.node.altText || node.title}
            className="rounded-xl"
          />
          <h2 className="text-xl font-bold mt-4">{node.title}</h2>
          <p className="text-gray-600">{node.description}</p>
          <p className="text-lg font-semibold mt-2">
            {node.variants.edges[0].node.price.amount}{" "}
            {node.variants.edges[0].node.price.currencyCode}
          </p>
          <form action={`/checkout?variantId=${encodeURIComponent(node.variants.edges[0].node.id)}`}>
            <button
              type="submit"
              className="bg-black text-white px-4 py-2 rounded-lg mt-3"
            >
              Buy Now
            </button>
          </form>
        </div>
      ))}
    </main>
  );
}
