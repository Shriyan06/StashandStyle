"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";

type Product = {
  id: string;
  title: string;
  description: string;
  image: string | null;
  variantId: string | null;
  price: string | null;
  currencyCode: string | null;
};

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/shopify/products?first=8", { cache: "no-store" });
        const data = await res.json();
        setProducts(data.products || []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return <main className="p-10">Loading products…</main>;
  }

  return (
    <main className="p-6 md:p-10">
      <h1 className="text-3xl font-bold mb-6">Latest Products</h1>
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((p) => (
          <Card key={p.id} className="overflow-hidden">
            <CardContent className="p-4">
              {p.image ? (
                <img src={p.image} alt={p.title} className="rounded-lg w-full object-cover" />
              ) : (
                <div className="w-full h-48 bg-gray-100 rounded-lg" />
              )}
              <h2 className="text-xl font-semibold mt-4">{p.title}</h2>
              <p className="text-sm text-gray-600 line-clamp-3">{p.description}</p>
              <div className="flex items-center justify-between mt-4">
                <span className="font-medium">
                  {p.price ? `${p.price} ${p.currencyCode}` : "—"}
                </span>
                {p.variantId ? (
                  <form action={`/checkout?variantId=${encodeURIComponent(p.variantId)}`}>
                    <Button type="submit">Buy Now</Button>
                  </form>
                ) : (
                  <Button disabled>Unavailable</Button>
                )}
              </div>
              <div className="mt-3">
                <Link href={`/product/${encodeURIComponent(p.id)}`} className="text-sm underline">
                  View details
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>
    </main>
  );
}
