"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, Star, ShoppingBag, Menu, X, Plus, Minus, Truck, Shield, RotateCcw } from "lucide-react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { useCart } from "@/lib/cart-context"

const products = [
  {
    id: 1,
    name: "Coral Statement Necklace",
    price: 89.99,
    originalPrice: 109.99,
    images: [
      "/coral-statement-necklace-on-white-background.png",
      "/coral-necklace-lifestyle-1.png",
      "/coral-necklace-detail-clasp.png",
      "/coral-necklace-packaging.png",
    ],
    category: "jewelry",
    subcategory: "necklaces",
    rating: 4.8,
    reviews: 124,
    colors: [
      { name: "Coral", value: "coral", hex: "#F08E80" },
      { name: "Gold", value: "gold", hex: "#FFD700" },
      { name: "Silver", value: "silver", hex: "#C0C0C0" },
    ],
    sizes: ["16 inch", "18 inch", "20 inch"],
    description:
      "Make a bold statement with our stunning coral necklace, crafted from premium materials and designed to elevate any outfit. This eye-catching piece features carefully selected coral-toned beads arranged in an elegant pattern that catches the light beautifully.",
    features: [
      "Premium coral-toned materials",
      "Adjustable chain length",
      "Hypoallergenic metals",
      "Handcrafted design",
      "Gift box included",
    ],
    materials: "Gold-plated brass, coral-toned resin beads",
    care: "Clean with soft cloth, avoid water and chemicals",
    isNew: true,
    isSale: true,
    inStock: true,
    stockCount: 15,
  },
  {
    id: 2,
    name: "Leather Crossbody Bag",
    price: 129.99,
    images: [
      "/elegant-leather-crossbody-bag-in-neutral-tone.png",
      "/crossbody-bag-interior-view.png",
      "/crossbody-bag-strap-detail.png",
      "/crossbody-bag-lifestyle-wear.png",
    ],
    category: "bags",
    subcategory: "crossbody",
    rating: 4.9,
    reviews: 89,
    colors: [
      { name: "Brown", value: "brown", hex: "#8B4513" },
      { name: "Black", value: "black", hex: "#000000" },
      { name: "Tan", value: "tan", hex: "#D2B48C" },
    ],
    sizes: ["One Size"],
    description:
      "Crafted from genuine leather, this crossbody bag combines style and functionality. Perfect for daily use, it features multiple compartments to keep your essentials organized while maintaining a sleek, sophisticated appearance.",
    features: [
      "100% genuine leather",
      "Adjustable crossbody strap",
      "Multiple interior compartments",
      "Secure zip closure",
      "Gold-tone hardware",
    ],
    materials: "Genuine leather, cotton lining, metal hardware",
    care: "Use leather conditioner monthly, avoid excessive moisture",
    isNew: false,
    isSale: false,
    inStock: true,
    stockCount: 8,
  },
  {
    id: 3,
    name: "Rose Gold Drop Earrings",
    price: 64.99,
    images: [
      "/rose-gold-drop-earrings-elegant-design.png",
      "/rose-gold-earrings-close-up.png",
      "/rose-gold-earrings-lifestyle.png",
      "/rose-gold-earrings-gift-box.png",
    ],
    category: "jewelry",
    subcategory: "earrings",
    rating: 4.7,
    reviews: 156,
    colors: [
      { name: "Rose Gold", value: "rose-gold", hex: "#E8B4B8" },
      { name: "Gold", value: "gold", hex: "#FFD700" },
      { name: "Silver", value: "silver", hex: "#C0C0C0" },
    ],
    sizes: ["One Size"],
    description:
      "Delicate and elegant, these rose gold drop earrings feature sparkling crystal accents that catch the light with every movement. Perfect for both everyday wear and special occasions, they add a touch of sophistication to any look.",
    features: [
      "Rose gold plated finish",
      "Crystal accents",
      "Hypoallergenic posts",
      "Lightweight design",
      "Secure butterfly backs",
    ],
    materials: "Rose gold plated brass, cubic zirconia crystals",
    care: "Store in jewelry box, clean with soft cloth",
    isNew: true,
    isSale: false,
    inStock: true,
    stockCount: 22,
  },
]

export default function ProductPage() {
  const params = useParams()
  const router = useRouter()
  const productId = Number.parseInt(params.id as string)
  const product = products.find((p) => p.id === productId)

  const { items, addItem } = useCart()

  const [selectedImage, setSelectedImage] = useState(0)
  const [selectedColor, setSelectedColor] = useState(0)
  const [selectedSize, setSelectedSize] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <Link href="/catalog">
            <Button>Back to Catalog</Button>
          </Link>
        </div>
      </div>
    )
  }

  const handleQuantityChange = (change: number) => {
    const newQuantity = quantity + change
    if (newQuantity >= 1 && newQuantity <= product.stockCount) {
      setQuantity(newQuantity)
    }
  }

  const handleAddToCart = () => {
    const cartItem = {
      ...product,
      color: product.colors[selectedColor].name,
      size: product.sizes[selectedSize],
      quantity,
      maxStock: product.stockCount,
    }
    addItem(cartItem)
  }

  const handleOrderNow = () => {
    handleAddToCart()
    router.push("/checkout")
  }

  const cartItemCount = items.reduce((total, item) => total + item.quantity, 0)

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link href="/" className="text-2xl font-bold text-primary">
                Stash & Style
              </Link>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link
                  href="/"
                  className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Home
                </Link>
                <Link
                  href="/catalog"
                  className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Catalog
                </Link>
                <Link
                  href="/about"
                  className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  About
                </Link>
                <Link
                  href="/contact"
                  className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Contact
                </Link>
              </div>
            </div>

            {/* Cart and Mobile Menu */}
            <div className="flex items-center space-x-4">
              <Link href="/cart">
                <Button variant="ghost" size="sm" className="relative">
                  <ShoppingBag className="h-5 w-5" />
                  <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                </Button>
              </Link>

              {/* Mobile menu button */}
              <div className="md:hidden">
                <Button variant="ghost" size="sm" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                  {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-border">
                <Link
                  href="/"
                  className="text-muted-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  Home
                </Link>
                <Link
                  href="/catalog"
                  className="text-muted-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  Catalog
                </Link>
                <Link
                  href="/about"
                  className="text-muted-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  About
                </Link>
                <Link
                  href="/contact"
                  className="text-muted-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  Contact
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <nav className="flex text-sm text-muted-foreground">
          <Link href="/" className="hover:text-primary">
            Home
          </Link>
          <span className="mx-2">/</span>
          <Link href="/catalog" className="hover:text-primary">
            Catalog
          </Link>
          <span className="mx-2">/</span>
          <span className="text-foreground">{product.name}</span>
        </nav>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className="relative aspect-square overflow-hidden rounded-lg bg-muted">
              <img
                src={product.images[selectedImage] || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.isNew && <Badge className="bg-secondary text-secondary-foreground">New</Badge>}
                {product.isSale && <Badge className="bg-destructive text-destructive-foreground">Sale</Badge>}
              </div>
              <Button size="sm" className="absolute top-4 right-4" variant="secondary">
                <Heart className="h-4 w-4" />
              </Button>
            </div>

            {/* Thumbnail Images */}
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-square rounded-lg overflow-hidden border-2 transition-colors ${
                    selectedImage === index ? "border-primary" : "border-border hover:border-muted-foreground"
                  }`}
                >
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`${product.name} view ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2 text-balance">{product.name}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${
                          i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-muted-foreground">
                    {product.rating} ({product.reviews} reviews)
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-4 mb-6">
                <span className="text-3xl font-bold text-primary">${product.price}</span>
                {product.originalPrice && (
                  <span className="text-xl text-muted-foreground line-through">${product.originalPrice}</span>
                )}
                {product.isSale && (
                  <Badge className="bg-destructive text-destructive-foreground">
                    Save ${(product.originalPrice! - product.price).toFixed(2)}
                  </Badge>
                )}
              </div>
            </div>

            <p className="text-muted-foreground text-pretty">{product.description}</p>

            {/* Color Selection */}
            <div>
              <h3 className="font-semibold mb-3">Color: {product.colors[selectedColor].name}</h3>
              <div className="flex gap-3">
                {product.colors.map((color, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedColor(index)}
                    className={`w-10 h-10 rounded-full border-2 transition-colors ${
                      selectedColor === index
                        ? "border-primary border-4"
                        : "border-border hover:border-muted-foreground"
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  />
                ))}
              </div>
            </div>

            {/* Size Selection */}
            {product.sizes.length > 1 && (
              <div>
                <h3 className="font-semibold mb-3">Size: {product.sizes[selectedSize]}</h3>
                <div className="flex gap-2">
                  {product.sizes.map((size, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedSize(index)}
                      className={`px-4 py-2 border rounded-lg transition-colors ${
                        selectedSize === index
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-muted-foreground"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div>
              <h3 className="font-semibold mb-3">Quantity</h3>
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-border rounded-lg">
                  <Button variant="ghost" size="sm" onClick={() => handleQuantityChange(-1)} disabled={quantity <= 1}>
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="px-4 py-2 min-w-[3rem] text-center">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleQuantityChange(1)}
                    disabled={quantity >= product.stockCount}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <span className="text-sm text-muted-foreground">{product.stockCount} items in stock</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
              <Button size="lg" className="w-full" disabled={!product.inStock} onClick={handleAddToCart}>
                <ShoppingBag className="h-5 w-5 mr-2" />
                Add to Cart - ${(product.price * quantity).toFixed(2)}
              </Button>
              <Button
                size="lg"
                variant="secondary"
                className="w-full"
                disabled={!product.inStock}
                onClick={handleOrderNow}
              >
                Order Now
              </Button>
              {!product.inStock && <p className="text-destructive text-center">Currently out of stock</p>}
            </div>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 py-6 border-t border-border">
              <div className="text-center">
                <Truck className="h-6 w-6 mx-auto mb-2 text-primary" />
                <p className="text-sm font-medium">Free Shipping</p>
                <p className="text-xs text-muted-foreground">On orders over $75</p>
              </div>
              <div className="text-center">
                <Shield className="h-6 w-6 mx-auto mb-2 text-primary" />
                <p className="text-sm font-medium">Secure Payment</p>
                <p className="text-xs text-muted-foreground">100% protected</p>
              </div>
              <div className="text-center">
                <RotateCcw className="h-6 w-6 mx-auto mb-2 text-primary" />
                <p className="text-sm font-medium">Easy Returns</p>
                <p className="text-xs text-muted-foreground">30-day policy</p>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mt-16">
          <Tabs defaultValue="details" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="reviews">Reviews ({product.reviews})</TabsTrigger>
              <TabsTrigger value="shipping">Shipping & Returns</TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <h3 className="font-semibold mb-4">Product Features</h3>
                      <ul className="space-y-2">
                        {product.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-4">Materials & Care</h3>
                      <div className="space-y-4">
                        <div>
                          <p className="font-medium text-sm">Materials:</p>
                          <p className="text-muted-foreground">{product.materials}</p>
                        </div>
                        <div>
                          <p className="font-medium text-sm">Care Instructions:</p>
                          <p className="text-muted-foreground">{product.care}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="reviews" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">Customer reviews coming soon!</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Be the first to review this product and help other customers make informed decisions.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="shipping" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-semibold mb-3">Shipping Information</h3>
                      <ul className="space-y-2 text-muted-foreground">
                        <li>• Free standard shipping on orders over $75</li>
                        <li>• Standard shipping (5-7 business days): $5.99</li>
                        <li>• Express shipping (2-3 business days): $12.99</li>
                        <li>• Overnight shipping (1 business day): $24.99</li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-3">Returns & Exchanges</h3>
                      <ul className="space-y-2 text-muted-foreground">
                        <li>• 30-day return policy from date of delivery</li>
                        <li>• Items must be in original condition with tags</li>
                        <li>• Free return shipping for defective items</li>
                        <li>• Exchange or store credit available</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
