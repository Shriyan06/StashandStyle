"use client";

import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type Product = {
  id: string;
  title: string;
  description: string;
  image: string | null;
  variantId: string | null;
  price: string | null;
  currencyCode: string | null;
};

export default function CatalogPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/shopify/products?first=24", { cache: "no-store" });
      const data = await res.json();
      setProducts(data.products || []);
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    const term = q.toLowerCase();
    return products.filter(p => p.title.toLowerCase().includes(term) || (p.description || "").toLowerCase().includes(term));
  }, [q, products]);

  if (loading) return <main className="p-10">Loading catalog…</main>;

  return (
    <main className="p-6 md:p-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Catalog</h1>
        <div className="w-64">
          <Input placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} />
        </div>
      </div>
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(p => (
          <Card key={p.id}>
            <CardContent className="p-4">
              {p.image ? <img src={p.image} alt={p.title} className="rounded-lg w-full h-56 object-cover" /> : <div className="h-56 bg-gray-100 rounded-lg" />}
              <h2 className="text-lg font-semibold mt-3">{p.title}</h2>
              <p className="text-sm text-gray-600 line-clamp-2">{p.description}</p>
              <div className="flex items-center justify-between mt-3">
                <span className="font-medium">{p.price ? `${p.price} ${p.currencyCode}` : "—"}</span>
                {p.variantId ? (
                  <form action={`/checkout?variantId=${encodeURIComponent(p.variantId)}`}>
                    <Button type="submit">Buy</Button>
                  </form>
                ) : (
                  <Button disabled>Unavailable</Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </section>
    </main>
  );
}
