"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Heart, Star, Search, Filter, Grid, List, ShoppingBag, Menu, X } from "lucide-react"
import Link from "next/link"
import { useCart } from "@/lib/cart-context" // Fixed import path to match actual cart context location

// Product data structure
const products = [
  {
    id: 1,
    name: "Coral Statement Necklace",
    price: 89.99,
    originalPrice: 109.99,
    image: "/coral-statement-necklace-on-white-background.png",
    category: "jewelry",
    subcategory: "necklaces",
    rating: 4.8,
    reviews: 124,
    colors: ["coral", "gold", "silver"],
    description: "Elegant coral statement necklace perfect for special occasions",
    isNew: true,
    isSale: true,
  },
  {
    id: 2,
    name: "Leather Crossbody Bag",
    price: 129.99,
    image: "/elegant-leather-crossbody-bag-in-neutral-tone.png",
    category: "bags",
    subcategory: "crossbody",
    rating: 4.9,
    reviews: 89,
    colors: ["brown", "black", "tan"],
    description: "Premium leather crossbody bag with adjustable strap",
    isNew: false,
    isSale: false,
  },
  {
    id: 3,
    name: "Rose Gold Drop Earrings",
    price: 64.99,
    image: "/rose-gold-drop-earrings-elegant-design.png",
    category: "jewelry",
    subcategory: "earrings",
    rating: 4.7,
    reviews: 156,
    colors: ["rose-gold", "gold", "silver"],
    description: "Delicate rose gold drop earrings with crystal accents",
    isNew: true,
    isSale: false,
  },
  {
    id: 4,
    name: "Luxury Silk Scarf",
    price: 45.99,
    originalPrice: 65.99,
    image: "/luxury-silk-scarf-with-coral-pattern.png",
    category: "accessories",
    subcategory: "scarves",
    rating: 4.6,
    reviews: 73,
    colors: ["coral", "navy", "cream"],
    description: "100% silk scarf with beautiful coral pattern",
    isNew: false,
    isSale: true,
  },
  {
    id: 5,
    name: "Pearl Bracelet Set",
    price: 78.99,
    image: "/elegant-pearl-bracelet-set.png",
    category: "jewelry",
    subcategory: "bracelets",
    rating: 4.8,
    reviews: 92,
    colors: ["white", "cream", "pink"],
    description: "Classic pearl bracelet set with gold accents",
    isNew: true,
    isSale: false,
  },
  {
    id: 6,
    name: "Designer Tote Bag",
    price: 189.99,
    image: "/luxury-designer-tote-bag-coral.png",
    category: "bags",
    subcategory: "tote",
    rating: 4.9,
    reviews: 67,
    colors: ["coral", "black", "cream"],
    description: "Spacious designer tote bag perfect for work or travel",
    isNew: false,
    isSale: false,
  },
  {
    id: 7,
    name: "Crystal Hair Clips",
    price: 32.99,
    originalPrice: 42.99,
    image: "/elegant-crystal-hair-clips-set.png",
    category: "accessories",
    subcategory: "hair",
    rating: 4.5,
    reviews: 134,
    colors: ["clear", "gold", "silver"],
    description: "Set of 3 crystal hair clips for elegant styling",
    isNew: false,
    isSale: true,
  },
  {
    id: 8,
    name: "Vintage Chain Necklace",
    price: 95.99,
    image: "/vintage-gold-chain-necklace.png",
    category: "jewelry",
    subcategory: "necklaces",
    rating: 4.7,
    reviews: 88,
    colors: ["gold", "silver", "rose-gold"],
    description: "Vintage-inspired chain necklace with unique pendant",
    isNew: true,
    isSale: false,
  },
]

const categories = [
  { id: "all", name: "All Products", count: products.length },
  { id: "jewelry", name: "Jewelry", count: products.filter((p) => p.category === "jewelry").length },
  { id: "bags", name: "Bags", count: products.filter((p) => p.category === "bags").length },
  { id: "accessories", name: "Accessories", count: products.filter((p) => p.category === "accessories").length },
]

const sortOptions = [
  { value: "featured", label: "Featured" },
  { value: "price-low", label: "Price: Low to High" },
  { value: "price-high", label: "Price: High to Low" },
  { value: "rating", label: "Highest Rated" },
  { value: "newest", label: "Newest" },
]

export default function CatalogPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("featured")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [showFilters, setShowFilters] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { items } = useCart() // Now using correct import

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = products

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter((product) => product.category === selectedCategory)
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Sort products
    switch (sortBy) {
      case "price-low":
        filtered.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        filtered.sort((a, b) => b.price - a.price)
        break
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "newest":
        filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0))
        break
      default:
        // Featured - keep original order
        break
    }

    return filtered
  }, [selectedCategory, searchQuery, sortBy])

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link href="/" className="text-2xl font-bold text-primary">
                Stash & Style
              </Link>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link
                  href="/"
                  className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Home
                </Link>
                <Link
                  href="/catalog"
                  className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Catalog
                </Link>
                <Link
                  href="/about"
                  className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  About
                </Link>
                <Link
                  href="/contact"
                  className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors"
                >
                  Contact
                </Link>
              </div>
            </div>

            {/* Cart and Mobile Menu */}
            <div className="flex items-center space-x-4">
              <Link href="/cart">
                <Button variant="ghost" size="sm" className="relative">
                  <ShoppingBag className="h-5 w-5" />
                  <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {items.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                </Button>
              </Link>

              {/* Mobile menu button */}
              <div className="md:hidden">
                <Button variant="ghost" size="sm" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                  {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-border">
                <Link
                  href="/"
                  className="text-muted-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  Home
                </Link>
                <Link
                  href="/catalog"
                  className="text-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  Catalog
                </Link>
                <Link
                  href="/about"
                  className="text-muted-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  About
                </Link>
                <Link
                  href="/contact"
                  className="text-muted-foreground hover:text-primary block px-3 py-2 text-base font-medium"
                >
                  Contact
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Page Header */}
      <div className="bg-muted/30 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-foreground mb-4 text-balance">Our Collection</h1>
          <p className="text-lg text-muted-foreground text-pretty">
            Discover beautiful accessories crafted for the modern woman
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <div className={`lg:w-64 ${showFilters ? "block" : "hidden lg:block"}`}>
            <div className="space-y-6">
              {/* Search */}
              <div>
                <h3 className="font-semibold mb-3">Search</h3>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Categories */}
              <div>
                <h3 className="font-semibold mb-3">Categories</h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                        selectedCategory === category.id ? "bg-primary text-primary-foreground" : "hover:bg-muted"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span>{category.name}</span>
                        <span className="text-sm opacity-70">({category.count})</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <div className="flex items-center gap-4">
                <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className="lg:hidden">
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                </Button>
                <p className="text-muted-foreground">{filteredAndSortedProducts.length} products found</p>
              </div>

              <div className="flex items-center gap-4">
                {/* Sort */}
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  {sortOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>

                {/* View Mode */}
                <div className="flex border border-border rounded-lg">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className="rounded-r-none"
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="rounded-l-none"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Products Grid/List */}
            {filteredAndSortedProducts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">No products found matching your criteria.</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchQuery("")
                    setSelectedCategory("all")
                  }}
                  className="mt-4"
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className={viewMode === "grid" ? "grid sm:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
                {filteredAndSortedProducts.map((product) => (
                  <Card key={product.id} className="group cursor-pointer hover:shadow-lg transition-shadow">
                    <CardContent className={viewMode === "grid" ? "p-0" : "p-4"}>
                      {viewMode === "grid" ? (
                        <>
                          <div className="relative overflow-hidden rounded-t-lg">
                            <Link href={`/product/${product.id}`}>
                              <img
                                src={product.image || "/placeholder.svg"}
                                alt={product.name}
                                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                              />
                            </Link>
                            <div className="absolute top-4 left-4 flex flex-col gap-2">
                              {product.isNew && <Badge className="bg-secondary text-secondary-foreground">New</Badge>}
                              {product.isSale && (
                                <Badge className="bg-destructive text-destructive-foreground">Sale</Badge>
                              )}
                            </div>
                            <Button
                              size="sm"
                              className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                              variant="secondary"
                            >
                              <Heart className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="p-4">
                            <Link href={`/product/${product.id}`}>
                              <h3 className="font-semibold text-lg mb-2 text-balance hover:text-primary transition-colors cursor-pointer">
                                {product.name}
                              </h3>
                            </Link>
                            <p className="text-sm text-muted-foreground mb-3 text-pretty">{product.description}</p>
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <span className="text-2xl font-bold text-primary">${product.price}</span>
                                {product.originalPrice && (
                                  <span className="text-sm text-muted-foreground line-through">
                                    ${product.originalPrice}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center">
                                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                <span className="text-sm text-muted-foreground ml-1">
                                  {product.rating} ({product.reviews})
                                </span>
                              </div>
                            </div>
                            <div className="flex gap-2 mb-4">
                              {product.colors.slice(0, 3).map((color, index) => (
                                <div
                                  key={index}
                                  className={`w-6 h-6 rounded-full border-2 border-border ${
                                    color === "coral"
                                      ? "bg-primary"
                                      : color === "gold"
                                        ? "bg-yellow-400"
                                        : color === "silver"
                                          ? "bg-gray-300"
                                          : color === "rose-gold"
                                            ? "bg-pink-300"
                                            : color === "black"
                                              ? "bg-black"
                                              : color === "brown"
                                                ? "bg-amber-700"
                                                : color === "tan"
                                                  ? "bg-amber-200"
                                                  : color === "navy"
                                                    ? "bg-blue-900"
                                                    : color === "cream"
                                                      ? "bg-amber-50"
                                                      : color === "white"
                                                        ? "bg-white"
                                                        : color === "pink"
                                                          ? "bg-pink-200"
                                                          : color === "clear"
                                                            ? "bg-gray-100"
                                                            : "bg-gray-400"
                                  }`}
                                />
                              ))}
                              {product.colors.length > 3 && (
                                <span className="text-xs text-muted-foreground self-center">
                                  +{product.colors.length - 3}
                                </span>
                              )}
                            </div>
                            <Link href={`/product/${product.id}`}>
                              <Button className="w-full" size="sm">
                                View Details
                              </Button>
                            </Link>
                          </div>
                        </>
                      ) : (
                        <div className="flex gap-4">
                          <div className="relative w-32 h-32 flex-shrink-0">
                            <Link href={`/product/${product.id}`}>
                              <img
                                src={product.image || "/placeholder.svg"}
                                alt={product.name}
                                className="w-full h-full object-cover rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                              />
                            </Link>
                            <div className="absolute top-2 left-2 flex flex-col gap-1">
                              {product.isNew && (
                                <Badge className="bg-secondary text-secondary-foreground text-xs">New</Badge>
                              )}
                              {product.isSale && (
                                <Badge className="bg-destructive text-destructive-foreground text-xs">Sale</Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start mb-2">
                              <Link href={`/product/${product.id}`}>
                                <h3 className="font-semibold text-lg text-balance hover:text-primary transition-colors cursor-pointer">
                                  {product.name}
                                </h3>
                              </Link>
                              <Button size="sm" variant="ghost">
                                <Heart className="h-4 w-4" />
                              </Button>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3 text-pretty">{product.description}</p>
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <span className="text-xl font-bold text-primary">${product.price}</span>
                                {product.originalPrice && (
                                  <span className="text-sm text-muted-foreground line-through">
                                    ${product.originalPrice}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center">
                                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                <span className="text-sm text-muted-foreground ml-1">
                                  {product.rating} ({product.reviews})
                                </span>
                              </div>
                            </div>
                            <div className="flex justify-between items-center">
                              <div className="flex gap-2">
                                {product.colors.slice(0, 4).map((color, index) => (
                                  <div
                                    key={index}
                                    className={`w-5 h-5 rounded-full border border-border ${
                                      color === "coral"
                                        ? "bg-primary"
                                        : color === "gold"
                                          ? "bg-yellow-400"
                                          : color === "silver"
                                            ? "bg-gray-300"
                                            : color === "rose-gold"
                                              ? "bg-pink-300"
                                              : color === "black"
                                                ? "bg-black"
                                                : color === "brown"
                                                  ? "bg-amber-700"
                                                  : color === "tan"
                                                    ? "bg-amber-200"
                                                    : color === "navy"
                                                      ? "bg-blue-900"
                                                      : color === "cream"
                                                        ? "bg-amber-50"
                                                        : color === "white"
                                                          ? "bg-white"
                                                          : color === "pink"
                                                            ? "bg-pink-200"
                                                            : color === "clear"
                                                              ? "bg-gray-100"
                                                              : "bg-gray-400"
                                    }`}
                                  />
                                ))}
                              </div>
                              <Link href={`/product/${product.id}`}>
                                <Button size="sm">View Details</Button>
                              </Link>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
